navbar
asdfasdf
<?php /**PATH /var/www/html/resources/views/components/default-navbar.blade.php ENDPATH**/ ?>