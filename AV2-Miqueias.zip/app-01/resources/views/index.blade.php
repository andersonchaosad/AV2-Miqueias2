@extends('layouts.base')

@section('navbar')
    @include('components.navbar')
@endsection

@section('content')
    adsfasdkf
@endsection
